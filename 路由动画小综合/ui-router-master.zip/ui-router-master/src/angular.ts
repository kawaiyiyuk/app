declare var angular;
import * as ng_from_import from "angular";
let ng_from_global = angular;

export const ng = (ng_from_import && ng_from_import.module) ? ng_from_import : ng_from_global;
