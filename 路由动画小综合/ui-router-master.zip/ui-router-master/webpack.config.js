// <package>/../../src/ is copied to <package>/src
// This config is then copied to <package>/src/webpack.config.js

var pkg = require('./package.json');
var banner = pkg.description + '\n' +
    '@version v' + pkg.version + '\n' +
    '@link ' + pkg.homepage + '\n' +
    '@license MIT License, http://www.opensource.org/licenses/MIT';

var webpack = require('webpack');
module.exports = {
  entry: {
    "angular-ui-router": "./src/ng1.ts",
    "angular-ui-router.min": "./src/ng1.ts",
    "stateEvents": "./src/ng1/legacy/stateEvents.ts",
    "stateEvents.min": "./src/ng1/legacy/stateEvents.ts",
  },

  output: {
    path: __dirname + "/release",
    filename: "[name].js",
    libraryTarget: "umd",
    library: "angular-ui-router",
    umdNamedDefine: true
  },

  devtool: 'source-map',

  resolve: {
    modulesDirectories: ['node_modules'],
    extensions: ['', '.js', '.ts']
  },

  plugins: [
    new webpack.optimize.UglifyJsPlugin({
      include: /\.min\.js$/, minimize: true
    }),
    new webpack.BannerPlugin(banner)
  ],

  module: {
    loaders: [
      { test: /\.ts$/, loader: "awesome-typescript-loader?declaration=false" }
    ]
  },

  ts: {
    compilerOptions: {
      declaration: false
    }
  },
 
  externals: {
    "angular": { root: 'angular', amd: 'angular', commonjs2: 'angular', commonjs: 'angular' }
  }
};
